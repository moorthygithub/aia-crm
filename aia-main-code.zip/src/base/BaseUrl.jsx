const BASE_URL = "https://agstest.online/public";

export default BASE_URL;
