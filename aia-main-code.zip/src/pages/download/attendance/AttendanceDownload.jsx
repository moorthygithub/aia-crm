import React from "react";

const AttendanceDownload = () => {
  return <div>AttendanceDownload</div>;
};

export default AttendanceDownload;
